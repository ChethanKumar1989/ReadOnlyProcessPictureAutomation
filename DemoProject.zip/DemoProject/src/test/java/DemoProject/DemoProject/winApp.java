package DemoProject.DemoProject;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.Scanner;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.DesiredCapabilities;

import io.appium.java_client.windows.WindowsDriver;
import io.appium.java_client.windows.WindowsElement;

public class winApp {
	
	public static void main(String[] args) throws InterruptedException  {
		DesiredCapabilities cap = new DesiredCapabilities();
		//cap.setCapability("app", "C:\\Windows\\System32\\calc.exe");
		cap.setCapability("app", "C:\\Program Files (x86)\\Cytiva\\UNICORN\\UNICORN 7.10\\bin\\UNICORNClient.exe");
		//cap.setCapability("app","{7C5A40EF-A0FB-4BFC-874A-C0F2E0B9FA8E}\\Cytiva\\UNICORN\\UNICORN 7.10\\bin\\UNICORNClient.exe");
		cap.setCapability("platformName","Windows");
	     cap.setCapability("deviceName", "WindowsPC");
	     
		WindowsDriver driver= null;
		try {
			driver = new WindowsDriver(new URL("http://127.0.0.1:4723/"),cap);
			
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		Thread.sleep(2000);
		System.out.println("Unicorn application started\n");
		
		System.out.println("enter Y to exit application");
		
		
		/*Scanner scanner = new Scanner(System.in);
		String inputString = scanner.nextLine();*/
		      
        //read test data from excel
        readExcelData read =  new readExcelData();
		String UnicornPassword= read.retrieveExcelData("Password");
		System.out.println("Value read from excel = "+ UnicornPassword);
		String UnicornUserName= read.retrieveExcelData("UserName");
		System.out.println("Value read from excel = "+ UnicornUserName);
		String defaultLayout= read.retrieveExcelData("layout");
		System.out.println("Value read from excel = "+ defaultLayout);
		 
		
		String wndName = driver.getTitle();
		System.out.println("window name:  " + wndName);
		
				//Handle "Software License Agreement" window if appears		
			if (wndName.contains("Software License Agreement")) {
					System.out.println("Closing Software License Agreement window ");
					
				boolean wnd = driver.findElementByName("Do not show this during startup").isDisplayed();
				System.out.println(wnd+" : Software License Agreement window pops up");
					
				driver.findElement(By.name("Yes")).click();
				Thread.sleep(5000);
					
			}
			else
			{
				System.out.println("Software License Agreement window didnt launch");
			}
		
			Thread.sleep(2000);
			Set<String> wndId = driver.getWindowHandles();
			System.out.println(wndId +" window id of unicorn login screen ");
			for (String window : wndId) 
			{ 
			driver.switchTo().window(window);
			System.out.println(driver.getTitle() +" : switch to login window screen");
			}
			
	
			System.out.println(driver.findElementByXPath("//Pane[@Name='Password'][@AutomationId='txtPassword']").isDisplayed()+"----Password txt box displayed----****");
		 /*driver.findElementByClassName("WindowsForms10.Edit.app.0.2a2cc74_r3_ad1").sendKeys(UnicornPassword);*/
			driver.findElementByXPath("//Pane[@Name='Password'][@AutomationId='txtPassword']").sendKeys(UnicornPassword);
		//select check box options in login screen
			
		boolean admin = driver.findElementByName("Administration").isSelected();
		if (!admin) {
			driver.findElementByName("Administration").click();
			System.out.println("Adminstration option selected");
		}
		boolean sc = driver.findElementByName("System Control").isSelected();
		if (sc)
		{
			driver.findElementByName("System Control").click();	
			System.out.println("System Control option selected");
		}
		
		boolean meditor = driver.findElementByName("Method Editor").isSelected();
		if (meditor)
		{
			driver.findElementByName("Method Editor").click();	
			System.out.println("Method editor option UnChecked");
		}
		
		boolean eval = driver.findElementByName("Evaluation").isSelected();
		if (eval)
		{
			driver.findElementByName("Evaluation").click();
			System.out.println("Evaluation option Unchecked");
		}
		
		//mouser over login button
		Actions action = new Actions(driver);
		//identify login button
		WebElement loginElement = driver.findElementByXPath("//Button[@Name='LOG IN']");
		//Performing the mouse hover action on the target element.
		action.moveToElement(loginElement).perform();
		
		//click login
		loginElement.click();
		System.out.println("Login button clicked in login screen");
		
		//Default Layout Selection
//		String wndName1 = driver.getTitle();
//		System.out.println("window name:  " + wndName1);
		try {
			boolean wndName1 = driver.findElementByXPath("//Window[@Name='Default Layout Selection']").isDisplayed();
			//Handle "Default Layout Selection" window if appears		
		if (wndName1) {
				System.out.println("Closing Default Layout Selection window ");
				
			boolean wnd1 = driver.findElementByXPath("//Window[@Name='Default Layout Selection']").isDisplayed();
			System.out.println(wnd1+" : window exists");
				
			driver.findElementByXPath("//ComboBox[@Name='Default layout']").sendKeys(defaultLayout);
			
			driver.findElementByXPath("//Button[@Name='OK'][@AutomationId='btnOK']").click();
			
			Thread.sleep(5000);
				
		}
		
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("default layout window did'nt launch");
		}
			
		Thread.sleep(15000);
		
		//select process picture
		Set<String> wndSCId = driver.getWindowHandles();
		System.out.println(wndSCId +" window id of unicorn login screen ");
		for (String window : wndSCId) 
		{ 
		driver.switchTo().window(window);
		System.out.println(driver.getTitle() +" : switch to login window screen");
		}
		
		
		Thread.sleep(5000);
		
		driver.findElementByXPath("//Window[@Name='System Control'][@AutomationId='SystemControlDialog']").click();
		
		
		
		
		
		
	/*	if (inputString.equals("Y") || inputString.equals("y")) 
		{
			System.out.println("inside if");	
		}else
		{
			System.out.println("inside else");
		}
        System.out.println("Out side if");*/
        
        //driver.quit();
        System.out.println("Application closed");
	}

}
