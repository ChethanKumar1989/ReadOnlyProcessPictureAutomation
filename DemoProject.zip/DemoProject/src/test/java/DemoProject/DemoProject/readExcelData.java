package DemoProject.DemoProject;

import java.io.File;  
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Iterator;  
import org.apache.poi.ss.usermodel.Cell;  
import org.apache.poi.ss.usermodel.Row;  
import org.apache.poi.xssf.usermodel.XSSFSheet;  
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.reporters.jq.Main;  




public class readExcelData {

	public String retrieveExcelData(String reqData) {
	
		//Create an object of File class to open xlsx file
		String value= null;
try  
	{  
		File file = new File("C:\\automation\\Read Only Process Picture\\Test Data.xlsx");   //creating a new file instance  
		FileInputStream fis = new FileInputStream(file);   //obtaining bytes from the file  

			//creating Workbook instance that refers to .xlsx file  
			XSSFWorkbook wb = new XSSFWorkbook(fis);   
			XSSFSheet sheet = wb.getSheetAt(0);     //creating a Sheet object to retrieve object  

			Iterator<Row> itr = sheet.iterator();    //iterating over excel file  

				while (itr.hasNext())                 
					{  
						Row row = itr.next();  
						Iterator<Cell> cellIterator = row.cellIterator();   //iterating over each column  
						Cell rowCell = cellIterator.next();
						String data = String. valueOf(rowCell);

						if(data.equals(reqData))
							{
								while (cellIterator.hasNext())   
									{  
										Cell cell = cellIterator.next();  		
										System.out.print("Value read from excel in retrieveExcelData method from ReadExcelData class = "+cell.getStringCellValue() + "\t\t\t"); 
										value=cell.getStringCellValue();
										break;
							}
						}
						

						System.out.println("");  
					}  
	}  
	catch(Exception e)  
		{  
			e.printStackTrace();  
		}  

	return value;  
}
	
public static void main(String[] args) {
			readExcelData read =  new readExcelData();
			String val= read.retrieveExcelData("UserName");
			System.out.println("Value read from excel = "+ val);
	}
}



	

